// Eliteclasis Website JS - v2

document.addEventListener('DOMContentLoaded', () => {
  /* Smooth scrolling with offset for sticky navbar */
  const navbar = document.querySelector('.navbar');
  const navHeight = navbar ? navbar.offsetHeight : 0;

  function scrollToSection(id) {
    const section = document.getElementById(id);
    if (!section) return;
    const offsetTop = section.offsetTop - navHeight;
    window.scrollTo({ top: offsetTop, behavior: 'smooth' });
  }

  /* Attach scroll helper to global so inline handlers work */
  window.scrollToSection = scrollToSection;

  /* Smooth scrolling for nav links */
  document.querySelectorAll('.nav-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href').substring(1);
      scrollToSection(targetId);
    });
  });

  /* Edit mode toggle */
  const editBtn = document.getElementById('editModeBtn');
  let editing = false;
  editBtn.addEventListener('click', () => {
    editing = !editing;
    document.body.classList.toggle('editing', editing);
    editBtn.textContent = editing ? 'Save & Exit' : 'Edit Mode';
    document.querySelectorAll('.editable').forEach((el) => {
      el.contentEditable = editing;
    });
  });

  /* Contact form handling */
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        return;
      }

      // Remove existing alerts
      const oldAlert = contactForm.parentElement.querySelector('.status');
      if (oldAlert) oldAlert.remove();

      // Success message
      const successAlert = document.createElement('div');
      successAlert.className = 'status status--success';
      successAlert.textContent = 'Thank you. Your request has been received.';
      contactForm.parentElement.insertBefore(successAlert, contactForm);

      // Reset form
      contactForm.reset();

      // Auto-hide message after 5 seconds
      setTimeout(() => {
        successAlert.remove();
      }, 5000);
    });
  }
});
